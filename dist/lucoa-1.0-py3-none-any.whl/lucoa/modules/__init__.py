"""Modulos internos do LucoaScript."""

